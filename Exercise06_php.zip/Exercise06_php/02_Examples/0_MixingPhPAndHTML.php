
<HTML>
<HEAD>
</HEAD>
<BODY>

<H1>
<?php
// THE PURPOSE of this file is to show that you can
// mix html and php in one file.
// The PHP interpreter just ignores the HTML part and processes the
// PHP part!
echo "This is the first PHP section";
?>

</H1>
This is message from outside any PhP section!
<BR>

<B>
<?php
echo  "This is the second PHP section";
?>
</B>
</BODY>
</HTML>
