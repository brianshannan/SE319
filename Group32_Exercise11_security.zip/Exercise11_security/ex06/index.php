<?php
	//index php just needs to call user_validation
	header("Location: ./user/user_validation.php");
	exit;
?>
