<?php
   if ( isset( $_GET['COLOR'] ) ) {
      include( $_GET['COLOR'] . '.php' );
   }
?>