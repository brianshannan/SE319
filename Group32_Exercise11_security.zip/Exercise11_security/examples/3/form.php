<html>
<body>

<form action="fe.php" method="get">
   <select name="COLOR">
      <option value="red">red</option>
      <option value="blue">blue</option>
   </select>
   <input type="submit">
</form>

</html>
</body>
